const obj = {
    "prop1" : 1,
    "prop2" : 2,
    "prop3" : 3,
}
for(e of Object.keys(obj)) console.log(e, obj[e]);